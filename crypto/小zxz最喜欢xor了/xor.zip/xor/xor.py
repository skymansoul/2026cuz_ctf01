import os
import random  
FLAG_LEN = len(flag)

master_seed = os.urandom(32)
noise_seed = int.from_bytes(master_seed[:4], 'little')
with open("seed.bin", "wb") as f:
    f.write(master_seed)

class Noise:
    def __init__(self, seed):
        self.s = seed & 0xffffffff
    def step(self):
        self.s = (self.s * 1103515245 + 12345) & 0xffffffff
        x = self.s
        x ^= ((x << 7) | (x >> 25)) & 0xffffffff
        x ^= (x >> 11)
        self.s = x & 0xffffffff
        return (((x >> 16) & 0xff) ^ ((x >> 8) & 0xff)) & 0xff

rng = Noise(noise_seed)
cipher = []
feedback = 0x73
remaining = list(range(FLAG_LEN))

for _ in range(FLAG_LEN):
    r = random.Random(feedback)
    idx = r.choice(remaining)
    remaining.remove(idx)
    b = flag[idx]
    k = rng.step()
    x = b ^ k
    x ^= feedback
    x = (x + ((idx * 13) ^ 0x57)) & 0xff
    feedback = x
    cipher.append(x)

while len(cipher) < 16:
    cipher.append(random.randint(0, 255))

N = 4
matrix = [cipher[i:i+N] for i in range(0, 16, N)]

for r in range(N):
    shift = r
    row = matrix[r]
    matrix[r] = row[shift:] + row[:shift]

final_cipher = []
for i, row in enumerate(matrix):
    if i % 2 == 0:
        final_cipher.extend(row)
    else:
        final_cipher.extend(row[::-1])
part1 = final_cipher[::2]
part2 = final_cipher[1::2]
with open("cache.dat", "wb") as f:
    f.write(bytes(part1))
with open("audio.idx", "wb") as f:
    f.write(bytes(part2))
print("[+] 加密完成，生成文件：seed.bin, cache.dat, audio.idx")