from string import ascii_letters

def caesar_encrypt(msg, shift):
    table = ascii_letters
    res = ""

    for ch in msg:
        if ch in table:
            idx = table.index(ch)
            res += table[(idx + shift) % len(table)]
        else:
            res += ch

    return res


def vigenere_encrypt(msg, key):
    res = ""
    ki = 0

    for ch in msg:
        if ch.isalpha():

            if ch.islower():
                base = ord('a')
            else:
                base = ord('A')

            k = ord(key[ki % len(key)].lower()) - ord('a')

            res += chr((ord(ch) - base + k) % 26 + base)

            ki += 1
        else:
            res += ch

    return res


plaintext = "????????????????????"

tmp = caesar_encrypt(plaintext, ?)

cipher = vigenere_encrypt(tmp, "MiKu")

print(cipher)