from Crypto.Cipher import DES
from Crypto.Util.Padding import pad
import base64

KEY = b"********"
FLAG = b"CUZCTF{*************************}"
IV = b"\x00" * DES.block_size

def encrypt(plaintext, key):
    cipher = DES.new(key, DES.MODE_CBC, iv=IV)
    padded = pad(plaintext, DES.block_size)
    return cipher.encrypt(padded)

def main():
    ct = encrypt(FLAG, KEY)
    print(base64.b64encode(ct).decode())

if __name__ == "__main__":
    main()